<!DOCTYPE html>
<html>

<head>
    <title>Login</title>
    <link rel="stylesheet" href="entrar.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <script src="entrar.js"></script>
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Jost:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Jost:ital,wght@0,100..900;1,100..900&family=Krona+One&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Jost:ital,wght@0,100..900;1,100..900&family=Krona+One&family=League+Spartan:wght@100..900&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Jost:ital,wght@0,100..900;1,100..900&family=Krona+One&family=League+Spartan:wght@100..900&family=Lexend:wght@100..900&display=swap" rel="stylesheet">
</head>

<body>
    <div id="decoracao">
        <img src="logo.png" alt="">
    </div>
    <div id="cadastro">
        LOGIN
    </div>
    <div id="headercadastro">
        login
    </div>

    <div id="formulario">
        <form method="POST" action="entrar.php">
            <div id="linha1">
                e-mail
            </div>
            <div id="linha2">
                <input class="formulariostyle2" type="text" name="login" id="login"><br>
            </div>
            <div id="linha1">
                senha
            </div>
            <div id="linha2">
                <input class="formulariostyle2" type="password" name="senha" id="senha"><br>
            </div>

            <div>
                <input id="entrarbotao" type="submit" value="ENTRAR">
            </div>
        </form>
        <div id="fim">
            Já possui uma conta? 	&nbsp; <a id="txtlogin" class="txtlogin" href="/Site/Cadastrousuario/cadastro.php">Faça seu cadastro</a>
        </div>
        </form>


    </div>

</body>

</html>
<?php
session_start();

ini_set('display_errors', 1);
error_reporting(E_ALL);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login = $_POST['login'] ?? '';
    $senha = $_POST['senha'] ?? '';


    if (empty($login) || empty($senha)) {
        echo '<script>alert("Preencha todos os campos."); window.location.href="entrar.php";</script>';
        exit;
    }

    $connect = mysqli_connect("127.0.0.1", "root", "", "MeuCesto");
    if (!$connect) {
        die("Erro na conexão: " . mysqli_connect_error());
    }

    $stmt = mysqli_prepare($connect, "SELECT senha FROM Cliente WHERE email = ?");
    mysqli_stmt_bind_param($stmt, "s", $login);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_store_result($stmt);

    if (mysqli_stmt_num_rows($stmt) === 1) {
        mysqli_stmt_bind_result($stmt, $senhaHash);
        mysqli_stmt_fetch($stmt);

        if (password_verify($senha, $senhaHash)) {

            $_SESSION['usuario'] = $login;
            $_SESSION['logado'] = true;


            setcookie('usuario', $login, time() + (86400 * 7), '/');

            header('Location: ../index.php');
            exit;
        } else {
            echo '<script>alert("Senha incorreta."); window.location.href="entrar.php";</script>';
            exit;
        }
    } else {
        echo '<script>alert("Usuário não encontrado."); window.location.href="entrar.php";</script>';
        exit;
    }



    mysqli_stmt_close($stmt);
    mysqli_close($connect);
}
?>