<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <link rel="stylesheet" href="TelaPrincipal.css">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <script src="TelaPrincipal.js"></script>
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Jost:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Jost:ital,wght@0,100..900;1,100..900&family=Krona+One&display=swap" rel="stylesheet">

</head>

<body>
  <div class="cabecalho">

    <img id="logopaginaprincipal" src="logopaginaprincipal.png" alt="">
    <svg id="lupa" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><!--!Font Awesome Free 6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.-->
      <path d="M416 208c0 45.9-14.9 88.3-40 122.7L502.6 457.4c12.5 12.5 12.5 32.8 0 45.3s-32.8 12.5-45.3 0L330.7 376c-34.4 25.2-76.8 40-122.7 40C93.1 416 0 322.9 0 208S93.1 0 208 0S416 93.1 416 208zM208 352a144 144 0 1 0 0-288 144 144 0 1 0 0 288z" />
    </svg>
    <input id="barradepesquisa" placeholder="O que procura?" type="text">
    <div id="opcoes">
      <a href=""><img src="./Icones/configuracoes.png" alt=""></a>
      <a href=""><img src="./Icones/coracao.png" alt=""></a>
      <a href=""><img src="./Icones/carrinho.png" alt=""></a>
      <a href=""><img src="./Icones/user.png" alt="">
    </div></a>
    <div id="opcoesdelogin">
      <a class="txtlogin" href="./Login/entrar.php">Entrar</a>
      <a class="txtlogin" href="./Cadastrousuario/cadastro.php">Cadastrar-se</a>

    </div>
  </div>
  <div id="barraverde"> </div>
  <div class="slideshow-container">

    <div class="mySlides fade">
      <div class="numbertext">1 / 3</div>
      <img src="./Banner/Placeholder1.png">
      <div class="text">Caption Text</div>
    </div>

    <div class="mySlides fade">
      <div class="numbertext">2 / 3</div>
      <img src="./Banner/Placeholder2.png">
      <div class="text">Caption Two</div>
    </div>

    <div class="mySlides fade">
      <div class="numbertext">3 / 3</div>
      <img src="./Banner/Placeholder3.png">
      <div class="text">Caption Three</div>
    </div>


    <div style>
      <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
      <a class="next" onclick="plusSlides(1)">&#10095;</a>
    </div>

  </div>
  <br>


  <div id="circulos">

    <div style="text-align:center">
      <span id="botaodefault" class="dot" onclick="currentSlide(1)"></span>
      <span class="dot" onclick="currentSlide(2)"></span>
      <span class="dot" onclick="currentSlide(3)"></span>
    </div>

  </div>
  <div class="titulinho">
    Feiras
  </div>
  <section class="carousel-container">
    <h2 class="title"></h2>

    <div class="carousel-wrapper">
      <button class="nav left" onclick="moveSlide(-1)">&#10094;</button>

      <div class="carousel-viewport">
        <div class="carousel" id="carousel">

          <div class="carousel-item"><img src="./FeirasPlaceholder/feira1.jpg">
            <p>Lorem Ipsum</p>
          </div>
          <div class="carousel-item"><img src="./FeirasPlaceholder/feira2.jpeg">
            <p>Lorem Ipsum</p>
          </div>
          <div class="carousel-item"><img src="./FeirasPlaceholder/feira3.jpeg">
            <p>Lorem Ipsum</p>
          </div>
          <div class="carousel-item"><img src="./FeirasPlaceholder/feira4.jpeg">
            <p>Lorem Ipsum</p>
          </div>
          <div class="carousel-item"><img src="./FeirasPlaceholder/feira5.jpeg">
            <p>Lorem Ipsum</p>
          </div>
          <div class="carousel-item"><img src="./FeirasPlaceholder/feira6.png">
            <p>Lorem Ipsum</p>
          </div>
          <div class="carousel-item"><img src="./FeirasPlaceholder/feira7.png">
            <p>Lorem Ipsum</p>
          </div>
          <div class="carousel-item"><img src="./FeirasPlaceholder/feira8.png">
            <p>Lorem Ipsum</p>
          </div>
          <div class="carousel-item"><img src="./FeirasPlaceholder/feira1.jpg">
            <p>Lorem Ipsum</p>
          </div>
        </div>
      </div>

      <button class="nav right" onclick="moveSlide(1)">&#10095;</button>
    </div>
  </section>
  <script>
    let currentIndex = 0;
    const itemsPerPage = 5;
    const itemWidth = 140;
    const carousel = document.getElementById("carousel");


    function moveSlide(direction) {
      const totalItems = carousel.children.length;
      const maxIndex = Math.ceil(totalItems / itemsPerPage) - 1;

      currentIndex += direction;

      if (currentIndex < 0) currentIndex = 0;
      if (currentIndex > maxIndex) currentIndex = maxIndex;

      const offset = currentIndex * itemWidth * itemsPerPage;
      carousel.style.transform = `translateX(-${offset}px)`;
    }

    // Torna a função global para funcionar com onclick
    window.moveSlide = moveSlide;
  </script>

  <div id="subtitulo">Mais RESERVADOS</div>
  <div id="produtos">
    Produtos
  </div>
  <h2 class="title"></h2>


</body>

</html>