<?php
session_start();
ini_set('display_errors', 1);
error_reporting(E_ALL);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['cadastrar'])) {
        die("Acesso inválido ao script");
    }

    $nome = trim($_POST['nome'] ?? '');
    $login = trim($_POST['login'] ?? '');
    $senha = $_POST['senha'] ?? '';

    if (empty($nome) || empty($login) || empty($senha)) {
        echo '<script>alert("Todos os campos devem ser preenchidos"); window.location.href="cadastro.php";</script>';
        exit;
    }

    if (!filter_var($login, FILTER_VALIDATE_EMAIL)) {
        echo '<script>alert("Por favor, insira um email válido"); window.location.href="cadastro.php";</script>';
        exit;
    }

    $connect = mysqli_connect("127.0.0.1", "root", "", "MeuCesto");
    if (!$connect) {
        die("Falha na conexão: " . mysqli_connect_error());
    }

    // Verifica se o email já existe
    $stmt = mysqli_prepare($connect, "SELECT email FROM Cliente WHERE email = ?");
    mysqli_stmt_bind_param($stmt, "s", $login);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_store_result($stmt);

    if (mysqli_stmt_num_rows($stmt) > 0) {
        echo '<script>alert("Este email já está cadastrado"); window.location.href="cadastro.php";</script>';
        mysqli_stmt_close($stmt);
        mysqli_close($connect);
        exit;
    }
    mysqli_stmt_close($stmt);

    $senhaHash = password_hash($senha, PASSWORD_DEFAULT);

    // Geração temporária de CPF para testes
    $cpf = uniqid(); // Ex: "66fa31c57488e"
    $telefone = '';  // Não coletado no formulário
    $feirante_id = null;
    $reserva_id = null;

    try {
        $stmt = mysqli_prepare($connect, "INSERT INTO Cliente (CPF, nome, telefone, senha, email, Feirante_id_feirante, Reserva_id_reserva) VALUES (?, ?, ?, ?, ?, ?, ?)");
        mysqli_stmt_bind_param($stmt, "sssssii", $cpf, $nome, $telefone, $senhaHash, $login, $feirante_id, $reserva_id);

        if (mysqli_stmt_execute($stmt)) {
            $_SESSION['usuario'] = $login;
            $_SESSION['logado'] = true;
            header('Location: ../index.php');
            exit;
        } else {
            throw new Exception(mysqli_error($connect));
        }
    } catch (Exception $e) {
        echo '<script>alert("Erro ao cadastrar: ' . addslashes($e->getMessage()) . '"); window.location.href="cadastro.php";</script>';
    } finally {
        if (isset($stmt)) mysqli_stmt_close($stmt);
        mysqli_close($connect);
    }
}
?>

<html>

<head>
    <title> Cadastro</title>
    <link rel="stylesheet" href="cadastro.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <script src="cadastro.js"></script>
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Jost:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Jost:ital,wght@0,100..900;1,100..900&family=Krona+One&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Jost:ital,wght@0,100..900;1,100..900&family=Krona+One&family=League+Spartan:wght@100..900&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Jost:ital,wght@0,100..900;1,100..900&family=Krona+One&family=League+Spartan:wght@100..900&family=Lexend:wght@100..900&display=swap" rel="stylesheet">
</head>

<body>
    <div id="decoracao">
        <img src="logo.png" alt="">
    </div>
    <div id="cadastro">
        CADASTRO
    </div>
    <div id="headercadastro">
        cadastrar
    </div>
    <div id="formulario">
        <form method="POST" action="cadastro.php">

            <div id="linha1">
                nome
            </div>
            <div id="linha2">
                <input class="formulariostyle2" type="nome" name="nome" id="nome" required><br>
            </div>
            <div id="linha1">
                e-mail
            </div>
            <div id="linha2">
                <input class="formulariostyle2" type="email" name="login" id="login" required><br>
            </div>
            <div id="linha1">
                senha
            </div>
            <div id="linha2">
                <input class="formulariostyle2" type="password" name="senha" id="senha" required><br>
            </div>
            <input id="cadastrarbotao" type="submit" value="CRIAR CONTA" id="cadastrar" name="cadastrar">
        </form>

        <div id="fim">
            Não possui uma conta? &nbsp;<a id="txtlogin" class="txtlogin" href="/Site/Login/entrar.php"> Faça Login</a>
        </div>



    </div>



</body>

</html>